import pymongo
import pandas as pd
from geopy.distance import geodesic
# MongoDB connection string
from bson.objectid import ObjectId
from datetime import datetime

mongo_uri = "mongodb+srv://morevansh2003:maideasy@cluster0.da2a1.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = pymongo.MongoClient(mongo_uri)

# Access the 'test' database
db = client['test']

# Fetch customer details
def get_customer_details(customer_id):
    customer = db.customers.find_one({"_id": ObjectId(customer_id)})
    return {
        "location": customer['area'],  # Fetch the customer's location
     #    "working_days": customer['workingDays']
    }

# Fetch job details (time, service)
def get_job_details(customer_id, service_id):
     job = db.jobs.find_one({"customerId": customer_id, "serviceId": service_id})
     return {
        "preferred_time": job['time'],  # Fetch preferred time
        "dates": job['dates'],  # Fetch date range
     #    "working_days": job['workingDays']
    }

# Fetch maid details
def get_maid_details():
    maids = db.maids.find({})
    maid_list = []
    for maid in maids:
        maid_list.append({
            "id": maid['_id'],
            "location": maid['preferredLocations'],
            "rating": maid['rating'],
            "time_slots": maid['timeSlots'],
            "working_days": maid['workingDays']
        })
    return maid_list

def is_time_in_slot(customer_time, maid_time_slots):
         # Convert customer time to 24-hour format for comparison
    customer_time_24hr = datetime.strptime(customer_time, '%I:%M %p').strftime('%H:%M')
    
    for time_slot in maid_time_slots:
        start_time, end_time = time_slot.split('-')  # Split the time range
        if start_time <= customer_time_24hr < end_time:  # Check if customer time falls in the range
            return True
            
    return False



# Filter maids based on location and availability
def match_maids(customer_id, service_id):
    customer = get_customer_details(customer_id)
    job = get_job_details(customer_id, service_id)
    matched_maids = []
    
    # Fetch all maids
    maids = get_maid_details()
    for maid in maids:
        # Step 1: Location Matching
        if customer['location'] in maid['location']:
          print(job['dates'])
          print(maid['working_days'])
          # Step 2: Availability Matching (day and time)
          if set(is_time_in_slot(job['preferred_time'], maid['time_slots'])):
               matched_maids.append({
                    "maid_id": maid['id'],
                    "rating": maid['rating']
                })
          # matched_maids.append({
          #      "maid_id": maid['id'],
          #      "rating": maid['rating']
          # })
    # Sort by rating
    matched_maids = sorted(matched_maids, key=lambda x: x['rating'], reverse=True)
    return matched_maids

# Test matching function
customer_id = ObjectId("67053e4634f5869c42331090")
service_id = ObjectId("6702a4befcbaf5bfc9bbab94")
best_maids = match_maids(customer_id, service_id)
print(best_maids)




# job['dates'].values()).intersection(maid['working_days']) or
# 67053e4634f5869c42331090